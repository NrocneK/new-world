DỊ MÔN — HAI CHƯƠNG CHƠI THỬ

Giải nén toàn bộ và mở tệp HTML trong gói. Gói đủ hai màn có level.html (màn 1), chapter-two.html (màn 2), campaign.html (thiết kế chiến dịch).
A/D: di chuyển; Shift: chạy; Space: nhảy hai lần; J: đánh và nối combo; K: né; U/I: lửa/gió; Escape: tạm dừng.
Màn 1: đi từ tầng 7 xuống trệt, cứu đồng nghiệp và hạ Kẻ Gác Cửa.
Màn 2: hộ tống tới trạm cứu thương, phá hai ổ dị giới và hạ Kẻ Truy Sát. Chọn THỬ NGÃ TƯ trên trang đầu màn 2 để chơi đoạn mẫu nâng cấp trong ô lưu riêng. Gió phản đạn; đòn móc/kết thúc phá giáp; thùng dầu có thể nổ.
Tiến trình lưu trên máy khi trình duyệt cho phép. Không cần mạng hoặc thư viện.
