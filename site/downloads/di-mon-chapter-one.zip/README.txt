DỊ MÔN — CHƯƠNG 01: KHI CÁNH CỔNG MỞ

Giải nén rồi mở di-mon-chapter-one.html bằng Chrome hoặc Edge. Chạy offline, không cần cài thư viện.
A/D hoặc phím mũi tên: di chuyển; Shift: chạy; Space: nhảy, bấm lại trên không để nhảy lần hai.
J: mỗi lần bấm một đòn, bấm liên tiếp để nối bốn đòn. J trên không: bay đá. K: né. U/I: lửa/gió khi mở khóa. Escape: tạm dừng.
Tiến trình tại điểm hồi sinh được lưu trên máy nếu trình duyệt cho phép localStorage.
