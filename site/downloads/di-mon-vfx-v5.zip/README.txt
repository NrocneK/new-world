DỊ MÔN — VFX BẢN 05

Giải nén rồi mở di-mon-vfx-v5.html bằng Chrome/Edge/Firefox.
HTML chứa sẵn hình và mã, không cần mạng hay máy chủ.
Bản này giữ nguyên VFX của bản 05; chỉ gom các hình dùng chung để tệp nhẹ hơn.
Bộ PNG và metadata nằm trong vfx/. ready/ có texture xuất từ bản xem thử.
Demo chính không thay đổi.
