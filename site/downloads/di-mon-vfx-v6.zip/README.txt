DỊ MÔN — KHÍ LỰC GỌN VÀ TRONG · BẢN 06

Mở vfx-review.html trong trình duyệt, chạy offline.
Hai đấm thẳng: bỏ lớp mây trắng nhòe, giữ các dải khí mảnh và khoảng trong; thu gọn luồng khí quanh nắm đấm, giữ trọn đuôi lướt ngang.
Demo chính online đã dùng cùng texture mới cho hai đòn này. Hình nhân vật và các động tác khác giữ nguyên.
Đấm móc, chấn động 360° và VFX đá trên không trong bản xem giữ nguyên từ v5.

vfx/ gồm manifest và bốn sheet đang dùng. ready/straight-clear.png là texture đã làm mềm đầu xa của đuôi, không áp dụng tailFeatherPixels lần nữa.
Demo chơi được: https://di-mon-demo.vercel.app/
