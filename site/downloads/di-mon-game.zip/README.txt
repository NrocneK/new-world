DỊ MÔN — HAI CHƯƠNG CHƠI THỬ

Giải nén toàn bộ. Mở level.html để chơi màn 1, chapter-two.html để chơi màn 2.
A/D: di chuyển; Shift: chạy; Space: nhảy hai lần; J: đánh và nối combo; K: né; U/I: lửa/gió; Escape: tạm dừng.
Màn 1: đi từ tầng 7 xuống trệt, cứu đồng nghiệp và hạ Kẻ Gác Cửa.
Màn 2: hộ tống tới trạm cứu thương, phá hai ổ dị giới và hạ Kẻ Truy Sát.
Tiến trình lưu trên máy khi trình duyệt cho phép. Không cần mạng hoặc thư viện.
